var searchData=
[
  ['getbarrier',['getBarrier',['../classmodel_1_1_board.html#a39c4df2abf0560a7bd33101495465564',1,'model::Board']]],
  ['getbigdoton',['getBigDotOn',['../classmodel_1_1_board.html#a9b57494d832c58da1776ff8ec72ae084',1,'model::Board']]],
  ['getbutton',['getButton',['../classview_1_1_main_menu_view.html#a3445cdf75530e63840a16fdf3c9c8c05',1,'view::MainMenuView']]],
  ['getcurrdirection',['getCurrDirection',['../classmodel_1_1_character.html#a126507b9548b31ba96e05cb3eb61e997',1,'model::Character']]],
  ['getcurrx',['getCurrX',['../classmodel_1_1_character.html#affc6134aac643540a1e9bdbb708f174e',1,'model::Character']]],
  ['getcurry',['getCurrY',['../classmodel_1_1_character.html#a4a91f92b8ebe7ff606a4a53c3819f202',1,'model::Character']]],
  ['getdot',['getDot',['../classmodel_1_1_board.html#aaa212cd5f01a313d67b22608815ec9dd',1,'model::Board']]],
  ['getenemy',['getEnemy',['../classmodel_1_1_board.html#ad99a1d88313ae3263a7c79bb6d0ad4e9',1,'model::Board']]],
  ['gethighscore',['getHighScore',['../classmodel_1_1_score.html#a673b14de52d29a4e0abe03419859c1b7',1,'model::Score']]],
  ['getlives',['getLives',['../classmodel_1_1_player.html#a6acd235f7d6deda31ca390566e3a0614',1,'model::Player']]],
  ['getpause',['getPause',['../classmodel_1_1_board.html#a7b23dd92f2fce0a55c95f51b1c062b3c',1,'model::Board']]],
  ['getplayer',['getPlayer',['../classmodel_1_1_board.html#a45d64fde5c3770a838347b25d33a44c0',1,'model::Board']]],
  ['getscore',['getScore',['../classmodel_1_1_score.html#a04b2d14cdcb0890ea7ead8076a5d24d5',1,'model::Score']]],
  ['getstop',['getStop',['../classmodel_1_1_character.html#af40b982d92fba5d4abbea27c8aa17a78',1,'model::Character']]],
  ['getview',['getView',['../classmodel_1_1_board.html#a18fef852326f094e342792f4e1e6d937',1,'model::Board']]]
];
