var searchData=
[
  ['quitgame',['quitGame',['../classmodel_1_1_board.html#a7695bd1eb7664dfffe7ee284afd8c859',1,'model.Board.quitGame()'],['../classview_1_1_board_view.html#a9166499c471835f42d20d8b0886a3b5f',1,'view.BoardView.quitGame()']]]
];
