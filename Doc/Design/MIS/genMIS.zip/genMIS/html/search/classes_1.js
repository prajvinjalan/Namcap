var searchData=
[
  ['character',['Character',['../classmodel_1_1_character.html',1,'model']]]
];
