var searchData=
[
  ['enemy',['Enemy',['../classmodel_1_1_enemy.html',1,'model']]]
];
