var searchData=
[
  ['changeplayerdirection',['changePlayerDirection',['../classmodel_1_1_board.html#aff68a5e6c3eaa796df0fa23ba017299c',1,'model::Board']]],
  ['changespeed',['changeSpeed',['../classmodel_1_1_enemy.html#a119318c55ec1441085d1542a7f06b85d',1,'model::Enemy']]],
  ['character',['Character',['../classmodel_1_1_character.html#aec117e46aa5c85c20a7f578be2b2979d',1,'model::Character']]],
  ['checkbigdottimer',['checkBigDotTimer',['../classmodel_1_1_board.html#ab0df7691dd796cdb3c2ec99a6b859abb',1,'model::Board']]],
  ['checkcollision',['checkCollision',['../classmodel_1_1_player.html#ab047df7e920a3c36a4a85b631ed9ddbb',1,'model::Player']]],
  ['checkdot',['checkDot',['../classmodel_1_1_player.html#a9e551996dd042e26005c3f5369d02d10',1,'model::Player']]],
  ['checkpausetime',['checkPauseTime',['../classmodel_1_1_board.html#a44f390a3237fbd3ae351bbf4dd320664',1,'model::Board']]],
  ['checktimerunning',['checkTimeRunning',['../classmodel_1_1_board.html#a0b73544e9b0b5f637023b055797031c1',1,'model::Board']]],
  ['createboard',['createBoard',['../classtesting_1_1_unit_tests.html#adf360af680a05fa526a6821ca509cc04',1,'testing::UnitTests']]],
  ['createmenu',['createMenu',['../classtesting_1_1_unit_tests.html#a4aa2ada153045259642cc17fb416f396',1,'testing::UnitTests']]]
];
