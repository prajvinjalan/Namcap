var searchData=
[
  ['bigdoteaten',['bigDotEaten',['../classmodel_1_1_enemy.html#a72512fb7208cbc1696ecb5eae9550076',1,'model::Enemy']]]
];
