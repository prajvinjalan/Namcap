var searchData=
[
  ['updateabnormalbarriers',['updateAbnormalBarriers',['../classview_1_1_board_view.html#abbc980e0455e9967bd04f8db63e45dbd',1,'view::BoardView']]],
  ['updatebarrier',['updateBarrier',['../classmodel_1_1_board.html#a351cd701c6875a303eeda91d64208ab5',1,'model.Board.updateBarrier(int x, int y)'],['../classmodel_1_1_board.html#a63325f0508f90c6bab11ba3e25c0c796',1,'model.Board.updateBarrier(ArrayList&lt; int[][]&gt; points)']]],
  ['updatedot',['updateDot',['../classmodel_1_1_board.html#ad1df8bebe1776d79092a77e8b6c163e4',1,'model.Board.updateDot(int x, int y, int type)'],['../classmodel_1_1_board.html#aab4a24afd7ce7fbb7c67c5a2a7f60b18',1,'model.Board.updateDot(ArrayList&lt; int[][]&gt; points)']]],
  ['updaterectanglebarriers',['updateRectangleBarriers',['../classview_1_1_board_view.html#ac2a71c4bb86e9834e73a1d50b5effee3',1,'view::BoardView']]],
  ['updateview',['updateView',['../classmodel_1_1_board.html#aa0a748a7e77b0093ba59ed589fbe8542',1,'model::Board']]]
];
