var searchData=
[
  ['player',['Player',['../classmodel_1_1_player.html',1,'model']]]
];
