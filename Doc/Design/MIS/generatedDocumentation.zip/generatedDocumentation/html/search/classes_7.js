var searchData=
[
  ['score',['Score',['../classmodel_1_1_score.html',1,'model']]]
];
