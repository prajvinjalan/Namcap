var searchData=
[
  ['ghost_2ejava',['Ghost.java',['../_ghost_8java.html',1,'']]]
];
