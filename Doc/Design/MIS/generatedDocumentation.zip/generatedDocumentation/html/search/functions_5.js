var searchData=
[
  ['getbarrier',['getBarrier',['../classmodel_1_1_board.html#a39c4df2abf0560a7bd33101495465564',1,'model::Board']]],
  ['getcurrdirection',['getCurrDirection',['../classmodel_1_1_character.html#a126507b9548b31ba96e05cb3eb61e997',1,'model::Character']]],
  ['getcurrx',['getCurrX',['../classmodel_1_1_character.html#affc6134aac643540a1e9bdbb708f174e',1,'model::Character']]],
  ['getcurry',['getCurrY',['../classmodel_1_1_character.html#a4a91f92b8ebe7ff606a4a53c3819f202',1,'model::Character']]],
  ['getdot',['getDot',['../classmodel_1_1_board.html#aaa212cd5f01a313d67b22608815ec9dd',1,'model::Board']]],
  ['getghost',['getGhost',['../classmodel_1_1_board.html#afa8b1f3fe16d4ee28c59c27213d1b5a6',1,'model::Board']]],
  ['getplayer',['getPlayer',['../classmodel_1_1_board.html#a45d64fde5c3770a838347b25d33a44c0',1,'model::Board']]],
  ['ghost',['Ghost',['../classmodel_1_1_ghost.html#a9d86fa64367ea976cfc957ba3a47e720',1,'model::Ghost']]],
  ['ghostmove',['ghostMove',['../classmodel_1_1_ghost.html#aa36c7af64884dd48a632a7415720bceb',1,'model::Ghost']]]
];
