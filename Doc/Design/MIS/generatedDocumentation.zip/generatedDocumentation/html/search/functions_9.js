var searchData=
[
  ['paintcomponent',['paintComponent',['../classview_1_1_board_view.html#ac2648ec3b4ceb6ea6b186cdba18364b9',1,'view::BoardView']]],
  ['player',['Player',['../classmodel_1_1_player.html#aaba7f16d9933538b426178c8ccfdb371',1,'model::Player']]]
];
