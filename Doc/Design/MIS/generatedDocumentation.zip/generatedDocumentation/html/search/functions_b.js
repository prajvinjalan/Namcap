var searchData=
[
  ['setframeinvis',['setFrameInvis',['../classview_1_1_main_menu_view.html#ab41027fd6ca30b5a5f975c9f2b9e7ced',1,'view::MainMenuView']]],
  ['setghost',['setGhost',['../classmodel_1_1_board.html#a123d946f993a3ca7521488b57e443aa3',1,'model::Board']]],
  ['setnewdirection',['setNewDirection',['../classmodel_1_1_character.html#aa3d0e1b5e84d9c350af278f8b702b685',1,'model::Character']]],
  ['setplayer',['setPlayer',['../classmodel_1_1_board.html#a6c7741744c6d611e0a573d6fae5e772b',1,'model::Board']]],
  ['setview',['setView',['../classmodel_1_1_board.html#a0135877df007d8560e38b6bc376a7844',1,'model.Board.setView()'],['../classmodel_1_1_main_menu.html#a95aa65b1fc8ca728b4cfa5bb1c907bf1',1,'model.MainMenu.setView()']]],
  ['startgame',['startGame',['../classmodel_1_1_main_menu.html#a0a7928281df0a6ba6ec4f24c1816dbf8',1,'model::MainMenu']]],
  ['stepframe',['stepFrame',['../classview_1_1_board_view.html#ad84986fe0d5086b09fc1a0e4199cab2f',1,'view::BoardView']]]
];
