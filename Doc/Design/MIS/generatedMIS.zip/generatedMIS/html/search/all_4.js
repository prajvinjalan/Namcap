var searchData=
[
  ['endgame',['endGame',['../classmodel_1_1_player.html#af5ab8506346b1dc7414c6180158aff72',1,'model.Player.endGame()'],['../classview_1_1_board_view.html#a1b735bc6ccea099de7188225e46bfeee',1,'view.BoardView.endGame()']]]
];
