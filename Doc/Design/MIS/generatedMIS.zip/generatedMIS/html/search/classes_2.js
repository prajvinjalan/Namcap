var searchData=
[
  ['ghost',['Ghost',['../classmodel_1_1_ghost.html',1,'model']]]
];
